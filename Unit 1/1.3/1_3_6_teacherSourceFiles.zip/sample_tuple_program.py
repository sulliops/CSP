my_favorite_animals = ('puffin', 'velociraptor', 'polar bear')

for critter in my_favorite_animals:
    print critter